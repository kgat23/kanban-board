// src/components/KanbanBoard.js
import React from "react";
import KanbanColumn from "./KanbanColumn";

function KanbanBoard({ tickets, grouping, ordering }) {
  const groupedTickets = groupTickets(tickets, grouping, ordering);

  return (
    <div className="kanban-board">
      {Object.keys(groupedTickets).map((group) => (
        <KanbanColumn key={group} title={group} tickets={groupedTickets[group]} />
      ))}
    </div>
  );
}

function groupTickets(tickets, grouping, ordering) {
  let grouped = {};
  
  tickets.forEach((ticket) => {
    const groupKey = ticket[grouping];
    if (!grouped[groupKey]) grouped[groupKey] = [];
    grouped[groupKey].push(ticket);
  });

  Object.keys(grouped).forEach((key) => {
    grouped[key].sort((a, b) => {
      if (ordering === "priority") return b.priority - a.priority;
      if (ordering === "title") return a.title.localeCompare(b.title);
      return 0;
    });
  });

  return grouped;
}

export default KanbanBoard;
