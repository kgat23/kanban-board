// src/App.js
import React, { useEffect, useState } from "react";
import { fetchKanbanData } from "./api/kanbanAPI";
import KanbanBoard from "./components/KanbanBoard";
import "./App.css";

function App() {
  const [tickets, setTickets] = useState([]);
  const [grouping, setGrouping] = useState("status"); // default grouping
  const [ordering, setOrdering] = useState("priority"); // default ordering

  useEffect(() => {
    const loadTickets = async () => {
      const data = await fetchKanbanData();
      setTickets(data);
    };
    loadTickets();
  }, []);

  return (
    <div className="App">
      <h1>Kanban Board</h1>
      <div className="controls">
        <select onChange={(e) => setGrouping(e.target.value)} value={grouping}>
          <option value="status">Status</option>
          <option value="user">User</option>
          <option value="priority">Priority</option>
        </select>
        <select onChange={(e) => setOrdering(e.target.value)} value={ordering}>
          <option value="priority">Priority</option>
          <option value="title">Title</option>
        </select>
      </div>
      <KanbanBoard tickets={tickets} grouping={grouping} ordering={ordering} />
    </div>
  );
}

export default App;
